create function get_all_users()
    returns TABLE(user_id integer, name character varying, lastname character varying, age integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT public.users_jdbc.user_id, public.users_jdbc.name, public.users_jdbc.lastname, public.users_jdbc.age FROM public.users_jdbc;
END;
$$;

alter function get_all_users() owner to postgres;

